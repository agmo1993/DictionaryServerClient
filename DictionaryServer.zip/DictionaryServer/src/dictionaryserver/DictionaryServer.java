package server;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DictionaryServer {

    public static JSONObject dictionary;
    public static String filepath;

    public static void main(String[] args) {

        try {
            if (args.length != 2) {
                throw new IllegalArgumentException("Incorrect number of arguments, please only enter two " +
                        "arguments");
            }

            int port = Integer.parseInt(args[0]);

            if (port > 65535 && port < 1025){
                throw new IllegalArgumentException("Port number has to be between 1024 and 65535");
            }

            filepath = args[1];
            DictionaryServer.openDictionary(args[1]);
            ThreadPooledServer server = new ThreadPooledServer(port);
            new Thread(server).start();
            Thread.sleep(20 * 10000);
            System.out.println("Stopping Server");
            server.stop();
            

        }

        catch (NumberFormatException e){
            System.out.println("Port input is incorrect.");
            System.out.println("Please try again");
            System.exit(1);
        }

        catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("Please try again");
            System.exit(1);
        }

        catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
            System.out.println("Please try again");
            System.exit(1);
        }


    }

    public static void writeDictionary(String filepath){
    try {
            PrintWriter file = new PrintWriter(filepath);
            file.write(dictionary.toJSONString());
            file.flush();
            file.close();
        }
        catch (FileNotFoundException f){
            System.out.println("Dictionary file not found.");
        }


    }

    public static void openDictionary(String filepath) {
        try {
            // parsing file
            FileReader reader = new FileReader(filepath);
            Object obj = new JSONParser().parse(reader);

            dictionary = (JSONObject) obj;
            reader.close();
        }

        catch (FileNotFoundException e){
            System.out.println("Dictionary file not found.");
        }

        catch (Exception e) {
            e.getMessage();
        }


    }


    public static String readJSON(String test) {
        String word = "Word not found";

            if (dictionary.get(test) == null){
                return word;
            }
            else{
                word = dictionary.get(test).toString();
            }

        return word;


    }


    public static synchronized String deletJSON(String test) {
        String word = "Word not found";

        if (dictionary.get(test) == null){
            return word;
        }
        else{
            dictionary.remove(test).toString();
            word = "Word deleted";
        }


        return word;


    }

    public static synchronized String writeJSON(String test, String def) {
        String word = "Word already present";

        if (dictionary.get(test) != null){
            return word;
        }
        else{
            dictionary.put(test,def);
            word = "Word added to dictionary";
            return word;
        }
        
    


}
}

class ThreadPooledServer implements Runnable{

    protected int          serverPort;
    protected ServerSocket serverSocket = null;
    protected boolean      isStopped    = false;
    protected Thread       runningThread= null;
    protected ExecutorService threadPool =
            Executors.newFixedThreadPool(10);

    public ThreadPooledServer(int port){
        this.serverPort = port;
    }

    public void run(){
        synchronized(this){
            this.runningThread = Thread.currentThread();
        }
        openServerSocket();
        while(! isStopped()){
            Socket clientSocket = null;
            try {
                clientSocket = this.serverSocket.accept();
            } catch (IOException e) {
                if(isStopped()) {
                    System.out.println("Server Stopped.") ;
                    break;
                }
                throw new RuntimeException(
                        "Error accepting client connection", e);
            }
            this.threadPool.execute(
                    new WorkerRunnable(clientSocket,
                            "Thread Pooled Server"));
        }
        this.threadPool.shutdown();
        System.out.println("Server Stopped.") ;
    }


    private synchronized boolean isStopped() {
        return this.isStopped;
    }

    public synchronized void stop(){
        this.isStopped = true;
        try {
            this.serverSocket.close();
        } catch (IOException e) {
            throw new RuntimeException("Error closing server", e);
        }
    }

    private void openServerSocket() {
        try {
            this.serverSocket = new ServerSocket(this.serverPort);
        } catch (IOException e) {
            throw new RuntimeException("Cannot open port 8080", e);
        }
    }
}


class WorkerRunnable implements Runnable{

    protected Socket clientSocket = null;
    protected String serverText   = null;

    public WorkerRunnable(Socket clientSocket, String serverText) {
        this.clientSocket = clientSocket;
        this.serverText   = serverText;
    }

    public void run() {
        try {

            ObjectInputStream JsonInput = new ObjectInputStream(clientSocket.getInputStream());
            Object messageRaw = JsonInput.readObject();
            String messageDigestReceived = JsonInput.readUTF();
            JSONObject message = (JSONObject) messageRaw;
            String requestType = message.get("Type").toString();

            ObjectOutputStream JsonOutput = new ObjectOutputStream(clientSocket.getOutputStream());

            byte [] messageDigestStart = JsonDigestor(message);
            String messageDigestOutput = Arrays.toString(messageDigestStart);

            if (!messageDigestReceived.equals(messageDigestOutput)){
                String result = "Security breach in communication, the first message was interrupted" +
                        " and hence the channel is not reliable, please try again later!";
                System.out.println(result);
                JSONObject messageToSend = JSONReply(requestType,result);
                System.out.println(messageToSend.toString());
                JsonOutput.writeObject(messageToSend);
                byte [] messageDigest = JsonDigestor(messageToSend);
                JsonOutput.writeUTF(Arrays.toString(messageDigest));
                System.out.println("Message sent");

            }

            else if (message.get("Type").equals("Read")) {
                String request = (message.get("Word")).toString();
                String result = DictionaryServer.readJSON(request);
                System.out.println(result);
                JSONObject messageToSend = JSONReply(requestType,result);
                System.out.println(messageToSend.toString());
                JsonOutput.writeObject(messageToSend);
                byte [] messageDigest = JsonDigestor(messageToSend);
                JsonOutput.writeUTF(Arrays.toString(messageDigest));
                System.out.println("Message sent");

                JsonOutput.flush();
            }
            else if (message.get("Type").equals("Delete")){
                String request = (message.get("Word")).toString();
                String result = DictionaryServer.deletJSON(request);
                System.out.println(result);
                JSONObject messageToSend = JSONReply(requestType,result);
                JsonOutput.writeObject(messageToSend);
                byte [] messageDigest = JsonDigestor(messageToSend);
                JsonOutput.writeUTF(Arrays.toString(messageDigest));
                System.out.println("Message sent");
                JsonOutput.flush();
            }

            else if (message.get("Type").equals("Add word")){
                String word = (message.get("Word")).toString();
                String definition = (message.get("definition")).toString();
                String result = DictionaryServer.writeJSON(word,definition);
                System.out.println(result);
                JSONObject messageToSend = JSONReply(requestType,result);
                JsonOutput.writeObject(messageToSend);
                byte [] messageDigest = JsonDigestor(messageToSend);
                JsonOutput.writeUTF(Arrays.toString(messageDigest));
                System.out.println("Message sent");
                JsonOutput.flush();
                DictionaryServer.writeDictionary(DictionaryServer.filepath);
            }


            long time = System.currentTimeMillis();

            System.out.println("Request processed: " + time);


        } catch (IOException e) {
            //report exception somewhere.
            e.printStackTrace();
        }


        catch (ClassNotFoundException f){
            f.getMessage();
        }


    }

    public JSONObject JSONReply(String requestType, String reply){

        //Below is the content of the message
        JSONObject message = new JSONObject();
        message.put("Type", requestType);
        message.put("Reply", reply);
        return message;
    }

    public byte[] JsonDigestor(JSONObject jsonreply){

        try {
            //Message digest added for security

            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] data1 = jsonreply.toString().getBytes("UTF-8");
            byte[] digest = messageDigest.digest(data1);
            return digest;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return "null".getBytes();

    }

    }

