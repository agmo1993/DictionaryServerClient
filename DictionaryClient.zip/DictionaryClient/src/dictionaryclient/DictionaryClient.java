/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionaryclient;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;

/**
 *
 * @author agmo
 */
public class DictionaryClient extends Application implements Initializable{
    
    Stage window;
    Scene scene1, scene2;
    JSONObject message;
    
    public static String ip;
    public static int port = 3020;
    
    @FXML
    private TextField enterWord;

    @FXML
    private TextField enterDefinition;

    @FXML
    public Label serverOutput;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        startView(primaryStage);


    }

    public void startView(Stage primaryStage) throws Exception{
        window=primaryStage;
        Parent root = FXMLLoader.load((getClass().getResource("sample.fxml")));
        scene1 = new Scene(root, 785, 748);
        primaryStage.setScene(scene1);
        primaryStage.show();
    }
    
    public void startViewAgain(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        Parent root = FXMLLoader.load((getClass().getResource("sample.fxml")));
        Stage window = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene1 = new Scene(root, 785, 748);
        window.setScene(scene1);
        window.show();
    }

    
    public void addWordScene(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        Parent root = FXMLLoader.load((getClass().getResource("addword.fxml")));
        Stage window = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene2 = new Scene(root, 785, 748);
        window.setScene(scene2);
        window.show();

    }

    public void findWordScene(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("findword.fxml"));
        Stage window = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene2 = new Scene(root, 785, 748);
        window.setScene(scene2);
        window.show();

    }


    public void deleteWordScene(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("deleteword.fxml"));
        Stage window = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene2 = new Scene(root, 785, 748);
        window.setScene(scene2);
        window.show();

    }

    public void addWordDefinition(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        message = JSONAdd(enterWord.getText(),enterDefinition.getText());
        System.out.println(message.toJSONString());
        String response = createSocket(message);
        serverOutput.setWrapText(true);
        serverOutput.setText(response);
    }

    public void findWordDefinition(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        message = JSONReadDelete("Read",enterWord.getText());
        System.out.println(message.toJSONString());
        String response = createSocket(message);
        serverOutput.setWrapText(true);
        serverOutput.setText(response);

    }

    public void deleteWordDefinition(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        message = JSONReadDelete("Delete",enterWord.getText());
        System.out.println(message.toJSONString());
        String response = createSocket(message);
        serverOutput.setWrapText(true);
        serverOutput.setText(response);
    }
    
    public void exit(javafx.scene.input.MouseEvent mouseEvent) throws Exception{
        System.exit(0);
    }

    public String createSocket(JSONObject messageFile){
        {
            
            try (Socket socket = new Socket(ip, port);) {
                // Output and Input Stream

                ObjectOutputStream jsonOutput = new ObjectOutputStream(socket.getOutputStream());
                jsonOutput.writeObject(messageFile);
                byte[] messageDigestStart = Jsondigestor(message);
                String messageDigestOutput = Arrays.toString(messageDigestStart);                       
                jsonOutput.writeUTF(messageDigestOutput);
                
                System.out.println("Data sent to Server--> ");
                jsonOutput.flush();

                //input for the JSON file
                ObjectInputStream jsonInput = new ObjectInputStream(socket.getInputStream());
                Object serverReply = jsonInput.readObject();
                String messagedigest = jsonInput.readUTF();
                System.out.println(messagedigest);

                JSONObject parsedReply = (JSONObject) serverReply;
                byte[] messagedigestReceived = Jsondigestor(parsedReply);

                System.out.println(parsedReply.toString());
                String messagedigest2 = Arrays.toString(messagedigestReceived);

                String reply = parsedReply.get("Reply").toString();

                if (messagedigest.equals(messagedigest2)){
                    return reply;
                    
                }
                else{
                    return "Security breach in communication, the message has been intercepted and " +
                            "is not reliable, please try again later!";
                   
                }
               
            } 
            
            catch (ConnectException e){
                String response = "Server is not runnning, please try again"
                        + " later.";
                return response;
            }

            
            catch (UnknownHostException e) {
                System.out.println("The host is not available or could not be"
                        + " found. Please re-enter the correct IP address or try"
                        + " again later.");
            } catch (IOException e) {
                e.printStackTrace();
            }

            catch (ClassNotFoundException f){
                f.printStackTrace();
            }
        }
        return "null";
    }

    public void click(javafx.scene.input.MouseEvent mouseEvent) {
        System.out.println("hello");
    }

    public JSONObject JSONReadDelete(String requestType, String word){
        JSONObject message = new JSONObject();
        message.put("Type", requestType);
        message.put("Word", word);
        return message;
    }

    public JSONObject JSONAdd(String word, String definition){
        JSONObject message = new JSONObject();
        message.put("Type", "Add word");
        message.put("Word", word);
        message.put("definition", definition);
        return message;
    }

    public byte[] Jsondigestor(JSONObject jsonreply){

        try {
            //Message digest added for security

            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] data1 = jsonreply.toString().getBytes("UTF-8");
            byte[] digest = messageDigest.digest(data1);
            return digest;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return "null".getBytes();

    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try{
        if (args.length != 2){
            throw new IllegalArgumentException("Incorrect Number of arguments,"
                    + "please only enter two arguments");
        }
                
        
        port = Integer.parseInt(args[0]);

        if (port > 65535 && port < 1025){
            throw new IllegalArgumentException("Port number has to be between"
                    + "1024 and 65535");
        }
        
        ip = args[1];
        
        launch(args);
        }
        catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        
    }
    
}
